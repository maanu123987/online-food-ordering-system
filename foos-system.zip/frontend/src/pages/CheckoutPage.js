import { Link } from 'react-router-dom';

export default function CheckoutPage() {
  return (
    <div className="form-card">
      <h2>Checkout</h2>
      <form>
        <input placeholder="Delivery Address" />
        <input placeholder="Phone Number" />
        <select>
          <option value="cash">Cash On Delivery</option>
          <option value="upi">UPI Payment</option>
          <option value="card">Card Payment</option>
        </select>
        <button className="btn btn-primary" type="submit">Place Order</button>
      </form>
      <p><Link to="/payment">Go to Payment</Link></p>
    </div>
  );
}
