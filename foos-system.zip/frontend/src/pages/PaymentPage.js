import { Link } from 'react-router-dom';

export default function PaymentPage() {
  return (
    <div className="form-card">
      <h2>Payment</h2>
      <p>Select a payment method to complete your order.</p>
      <select>
        <option value="cash">Cash On Delivery</option>
        <option value="upi">UPI</option>
        <option value="card">Card</option>
      </select>
      <button className="btn btn-primary">Pay Now</button>
      <p><Link to="/order-success">View Order Success</Link></p>
    </div>
  );
}
