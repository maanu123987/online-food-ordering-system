import { Link } from 'react-router-dom';

export default function FeedbackPage() {
  return (
    <div className="form-card">
      <h2>Feedback</h2>
      <form>
        <input placeholder="Food Item" />
        <input placeholder="Rating (1-5)" />
        <textarea placeholder="Write your review" rows="4" />
        <button className="btn btn-primary" type="submit">Submit Review</button>
      </form>
      <p><Link to="/profile">Back to Profile</Link></p>
    </div>
  );
}
