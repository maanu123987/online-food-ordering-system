import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/auth/forgot-password', { email });
      alert('Reset link sent');
    } catch (error) {
      alert('Request failed');
    }
  };

  return (
    <div className="form-card">
      <h2>Forgot Password</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <button className="btn btn-primary" type="submit">Send Reset Link</button>
      </form>
      <p><Link to="/login">Back to Login</Link></p>
    </div>
  );
}
