import { Link } from 'react-router-dom';

const featuredFoods = [
  { id: 1, name: 'Classic Burger', price: '$8.99', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80' },
  { id: 2, name: 'Pepper Pizza', price: '$12.49', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80' },
  { id: 3, name: 'French Fries', price: '$4.49', image: 'https://images.unsplash.com/photo-1576107232684-2cc3c0d8a3d5?auto=format&fit=crop&w=800&q=80' }
];

const reviews = [
  { name: 'Emily', comment: 'Fast delivery, delicious food, and a beautiful app experience.' },
  { name: 'David', comment: 'The menu is rich and the checkout is super smooth.' }
];

export default function HomePage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/about">About</Link>
          <Link to="/contact">Contact</Link>
          <Link to="/login">Login</Link>
          <Link to="/register">Register</Link>
        </div>
      </nav>

      <section className="hero">
        <div className="hero-card">
          <p style={{ color: 'var(--primary)', fontWeight: 700 }}>Fresh • Fast • Favorite</p>
          <h1>Delicious Food Delivered To Your Doorstep.</h1>
          <p>Enjoy burgers, pizza, pasta, desserts, and more from your favorite local kitchen.</p>
          <Link className="btn btn-primary" to="/login">Login</Link>
          <Link className="btn btn-secondary" to="/register">Register</Link>
          <Link className="btn btn-primary" to="/menu">View Menu</Link>
        </div>
        <img src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=900&q=80" alt="burger" />
      </section>

      <section className="section">
        <h2>Popular Foods</h2>
        <div className="cards">
          {featuredFoods.map((food) => (
            <div className="card" key={food.id}>
              <img src={food.image} alt={food.name} />
              <h3>{food.name}</h3>
              <p>{food.price}</p>
              <Link className="btn btn-primary" to={`/food/${food.id}`}>View Details</Link>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <h2>Featured Dishes</h2>
        <div className="cards">
          <div className="card">
            <h3>Smoky Chicken Sandwich</h3>
            <p>Loaded with juicy chicken, lettuce, and cheddar.</p>
          </div>
          <div className="card">
            <h3>Cheesy Pasta</h3>
            <p>Rich tomato sauce and melted mozzarella.</p>
          </div>
          <div className="card">
            <h3>Cold Drinks</h3>
            <p>Refreshing soft drinks and iced beverages.</p>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>Customer Reviews</h2>
        <div className="cards">
          {reviews.map((review) => (
            <div className="card" key={review.name}>
              <h3>{review.name}</h3>
              <p>{review.comment}</p>
            </div>
          ))}
        </div>
      </section>

      <footer>
        <p>© 2026 Foodie Rush. Delicious meals delivered to your doorstep.</p>
      </footer>
    </div>
  );
}
