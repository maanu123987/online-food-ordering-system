import { Link } from 'react-router-dom';

const orders = [
  { id: 1001, status: 'Delivered', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80', total: '$17.98' },
  { id: 1002, status: 'Preparing', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80', total: '$12.49' }
];

export default function OrderHistoryPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/profile">Profile</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Order History</h2>
        <div className="cards">
          {orders.map((order) => (
            <div className="card" key={order.id}>
              <img src={order.image} alt="order item" />
              <h3>Order #{order.id}</h3>
              <p>Status: {order.status}</p>
              <p>Total: {order.total}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
