import { Link } from 'react-router-dom';

export default function AboutPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      <section className="section">
        <div className="hero-card">
          <h2>About Us</h2>
          <p>Foodie Rush is a modern food delivery platform that connects hungry customers to their favorite restaurants and fresh meals.</p>
        </div>
      </section>
    </div>
  );
}
