import { Link } from 'react-router-dom';

export default function FoodDetailPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/cart">Cart</Link>
        </div>
      </nav>
      <section className="section">
        <div className="grid-2">
          <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80" alt="food" style={{ width: '100%', borderRadius: 18 }} />
          <div className="hero-card">
            <h2>Classic Burger</h2>
            <p>Fresh bun, grilled beef patty, melty cheese, lettuce, and tomato sauce.</p>
            <p><strong>Ingredients:</strong> Bun, Beef, Cheese, Lettuce, Tomato, Sauce</p>
            <p><strong>Price:</strong> $8.99</p>
            <label>Quantity</label>
            <input type="number" defaultValue="1" min="1" />
            <button className="btn btn-primary">Add To Cart</button>
          </div>
        </div>
      </section>
    </div>
  );
}
