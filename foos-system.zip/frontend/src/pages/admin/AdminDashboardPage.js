import { Link } from 'react-router-dom';

export default function AdminDashboardPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush Admin</strong></div>
        <div className="nav-links">
          <Link to="/admin/foods">Foods</Link>
          <Link to="/admin/categories">Categories</Link>
          <Link to="/admin/orders">Orders</Link>
          <Link to="/admin/users">Users</Link>
          <Link to="/admin/reports">Reports</Link>
        </div>
      </nav>
      <section className="section">
        <div className="cards">
          <div className="card"><h3>Orders</h3><p>120</p></div>
          <div className="card"><h3>Users</h3><p>540</p></div>
          <div className="card"><h3>Revenue</h3><p>$12,300</p></div>
        </div>
      </section>
    </div>
  );
}
