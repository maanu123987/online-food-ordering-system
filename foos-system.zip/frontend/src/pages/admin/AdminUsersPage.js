import { Link } from 'react-router-dom';

export default function AdminUsersPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Admin Panel</strong></div>
        <div className="nav-links">
          <Link to="/admin">Dashboard</Link>
          <Link to="/admin/orders">Orders</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Manage Users</h2>
        <div className="cards">
          <div className="card"><h3>John Doe</h3><p>Active</p></div>
          <div className="card"><h3>Sara</h3><p>Pending</p></div>
        </div>
      </section>
    </div>
  );
}
