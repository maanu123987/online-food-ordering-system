import { Link } from 'react-router-dom';

export default function AdminOrdersPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Admin Panel</strong></div>
        <div className="nav-links">
          <Link to="/admin">Dashboard</Link>
          <Link to="/admin/reports">Reports</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Manage Orders</h2>
        <div className="cards">
          <div className="card"><h3>Order #1001</h3><p>Status: Delivered</p></div>
          <div className="card"><h3>Order #1002</h3><p>Status: Out For Delivery</p></div>
        </div>
      </section>
    </div>
  );
}
