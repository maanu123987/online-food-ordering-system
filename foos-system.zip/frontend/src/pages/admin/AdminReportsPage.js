import { Link } from 'react-router-dom';

export default function AdminReportsPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Admin Panel</strong></div>
        <div className="nav-links">
          <Link to="/admin">Dashboard</Link>
          <Link to="/admin/orders">Orders</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Reports</h2>
        <div className="cards">
          <div className="card"><h3>Total Sales</h3><p>$24,500</p></div>
          <div className="card"><h3>Monthly Orders</h3><p>325</p></div>
        </div>
      </section>
    </div>
  );
}
