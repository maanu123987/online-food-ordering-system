import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/admin/login', form);
      localStorage.setItem('token', response.data.token);
      navigate('/admin');
    } catch (error) {
      alert('Admin login failed');
    }
  };

  return (
    <div className="form-card">
      <h2>Admin Login</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input type="password" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <button className="btn btn-primary" type="submit">Login</button>
      </form>
      <p><Link to="/">Back to Home</Link></p>
    </div>
  );
}
