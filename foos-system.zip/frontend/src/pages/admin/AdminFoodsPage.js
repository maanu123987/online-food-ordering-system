import { Link } from 'react-router-dom';

export default function AdminFoodsPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Admin Panel</strong></div>
        <div className="nav-links">
          <Link to="/admin">Dashboard</Link>
          <Link to="/admin/categories">Categories</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Manage Foods</h2>
        <button className="btn btn-primary">Add Food Item</button>
        <div className="cards">
          <div className="card"><h3>Burger</h3><p>Edit Delete Upload Image</p></div>
          <div className="card"><h3>Pizza</h3><p>Edit Delete Upload Image</p></div>
        </div>
      </section>
    </div>
  );
}
