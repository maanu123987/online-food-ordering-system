import { Link } from 'react-router-dom';

export default function AdminCategoriesPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Admin Panel</strong></div>
        <div className="nav-links">
          <Link to="/admin">Dashboard</Link>
          <Link to="/admin/foods">Foods</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Manage Categories</h2>
        <button className="btn btn-primary">Add Category</button>
        <div className="cards">
          <div className="card"><h3>Fast Food</h3></div>
          <div className="card"><h3>Drinks</h3></div>
        </div>
      </section>
    </div>
  );
}
