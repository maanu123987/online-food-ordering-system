import { Link } from 'react-router-dom';

export default function ContactPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/about">About</Link>
        </div>
      </nav>
      <section className="section">
        <div className="hero-card">
          <h2>Contact Us</h2>
          <p>Email: support@foodierush.com</p>
          <p>Phone: +1 555 888 1234</p>
          <p>Address: 12 Market Street, New York</p>
        </div>
      </section>
    </div>
  );
}
