import { Link } from 'react-router-dom';

const foods = [
  { id: 1, name: 'Burger', description: 'Juicy grilled burger with cheese.', price: '$8.99', rating: '4.8', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80' },
  { id: 2, name: 'Pizza', description: 'Crispy crust with rich tomato sauce.', price: '$12.49', rating: '4.9', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80' },
  { id: 3, name: 'French Fries', description: 'Golden crispy fries with herb seasoning.', price: '$4.49', rating: '4.7', image: 'https://images.unsplash.com/photo-1576107232684-2cc3c0d8a3d5?auto=format&fit=crop&w=800&q=80' },
  { id: 4, name: 'Sandwich', description: 'Toasted bread with fresh vegetables.', price: '$6.99', rating: '4.6', image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=800&q=80' },
  { id: 5, name: 'Pasta', description: 'Creamy pasta with basil and herbs.', price: '$9.99', rating: '4.8', image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=800&q=80' },
  { id: 6, name: 'Cold Drinks', description: 'Chilled beverages for your meal.', price: '$2.49', rating: '4.5', image: 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?auto=format&fit=crop&w=800&q=80' }
];

export default function MenuPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/cart">Cart</Link>
          <Link to="/orders">Orders</Link>
          <Link to="/profile">Profile</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Menu</h2>
        <div className="cards">
          {foods.map((food) => (
            <div className="card" key={food.id}>
              <img src={food.image} alt={food.name} />
              <h3>{food.name}</h3>
              <p>{food.description}</p>
              <p><strong>Price:</strong> {food.price}</p>
              <p><strong>Rating:</strong> {food.rating}</p>
              <Link className="btn btn-primary" to={`/food/${food.id}`}>View Details</Link>
              <button className="btn btn-secondary">Add To Cart</button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
