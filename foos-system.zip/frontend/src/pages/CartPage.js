import { Link } from 'react-router-dom';

const cartItems = [
  { id: 1, name: 'Classic Burger', quantity: 2, price: '$17.98', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80' },
  { id: 2, name: 'Pizza', quantity: 1, price: '$12.49', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80' }
];

export default function CartPage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/checkout">Checkout</Link>
        </div>
      </nav>
      <section className="section">
        <h2>Your Cart</h2>
        <div className="cards">
          {cartItems.map((item) => (
            <div className="card" key={item.id}>
              <img src={item.image} alt={item.name} />
              <h3>{item.name}</h3>
              <p>Quantity: {item.quantity}</p>
              <p>Price: {item.price}</p>
              <button className="btn btn-secondary">Remove</button>
            </div>
          ))}
        </div>
        <div className="hero-card" style={{ marginTop: 20 }}>
          <h3>Total Amount: $30.47</h3>
          <Link className="btn btn-primary" to="/checkout">Proceed To Checkout</Link>
        </div>
      </section>
    </div>
  );
}
