import { Link } from 'react-router-dom';

export default function OrderSuccessPage() {
  return (
    <div className="form-card">
      <h2>Order Confirmed!</h2>
      <p>Your food order has been placed successfully.</p>
      <p>Status: Order Placed</p>
      <Link className="btn btn-primary" to="/orders">View Order History</Link>
    </div>
  );
}
