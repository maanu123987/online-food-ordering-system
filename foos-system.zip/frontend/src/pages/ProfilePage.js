import { Link } from 'react-router-dom';

export default function ProfilePage() {
  return (
    <div>
      <nav className="navbar">
        <div><strong>Foodie Rush</strong></div>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/orders">Orders</Link>
          <Link to="/feedback">Feedback</Link>
        </div>
      </nav>
      <section className="section">
        <div className="hero-card">
          <h2>My Profile</h2>
          <p><strong>Name:</strong> John Doe</p>
          <p><strong>Email:</strong> john@example.com</p>
          <p><strong>Phone:</strong> +1 234 567</p>
          <button className="btn btn-primary">Edit Profile</button>
          <button className="btn btn-secondary">Change Password</button>
          <Link className="btn btn-primary" to="/orders">View Previous Orders</Link>
        </div>
      </section>
    </div>
  );
}
